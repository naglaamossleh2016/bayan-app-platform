# Bayan Admin UI (No Login)
- Desktop: sidebar expanded by default, hamburger toggle after "لوحة التحكم"
- Mobile: hamburger opens offcanvas-start
- Sidebar matches Bayan: title + subtitle + "القائمة" underline
- Sidebar icons: darker gold
- Offcanvas shows username + logout
- Single scroll (no internal sidebar scroll)
